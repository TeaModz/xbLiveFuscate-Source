namespace xbLiveFuscate
{

    public enum EndianStyle
    {
        LittleEndian,
        BigEndian
    }
}
